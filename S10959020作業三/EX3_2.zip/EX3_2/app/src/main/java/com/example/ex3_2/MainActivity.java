package com.example.ex3_2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    private TextView mTextView;
    private Button mButton;
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = findViewById(R.id.textView);
        mButton = findViewById(R.id.button);
        mRequestQueue = Volley.newRequestQueue(this);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://web.cs.wpi.edu/~cs1004/a16/Resources/SacramentoRealEstateTransactions.csv";
                mStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String[] lines = response.split("\n");
                        StringBuilder sb = new StringBuilder();
                        sb.append("No.\t\tAddress\t\tSize\t\tprice\n");
                        for (int i = 1; i < 4 && i < lines.length; i++) {
                            String[] datas = lines[i].split(",");
                            sb.append(i+"\t");
                            for (int j=0;j<4;j++){
                                sb.append(datas[j]+", ");
                            }
                            sb.append(datas[4]+" beds, "+datas[5]+" bath, "+datas[6]+" sqft $"+datas[9]+"\n");
                        }
                        mTextView.setText(sb.toString());
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        mTextView.setText("Error loading data.");
                    }
                });
                mRequestQueue.add(mStringRequest);
            }
        });
    }
}